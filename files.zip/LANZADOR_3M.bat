@echo off
:: =============================================================================
:: LANZADOR_3M.bat  —  Lanzador del 3M_SYSTEM
:: Ubicacion: C:\EXTERIOR\3M_SYSTEM\LANZADOR_3M.bat
:: =============================================================================

title 3M_SYSTEM - Lilis S.A.
color 0A
cd /d C:\EXTERIOR\3M_SYSTEM

:MENU
cls
echo.
echo  ============================================================
echo   3M_SYSTEM  ^|  Lilis S.A.  ^|  Proveedor 3M / Solventum
echo  ============================================================
echo.
echo   [1]  Inicializar base de datos (primera vez)
echo   [2]  Cargar TODOS los archivos de la carpeta INPUT
echo   [3]  Cargar un FIREX.txt
echo   [4]  Cargar una Invoice PDF
echo   [5]  Cargar un Packing List PDF
echo   [6]  Cargar una PO PDF
echo   [7]  Re-enlazar documentos
echo   [8]  Ver resumen de tablas
echo   [9]  Abrir carpeta INPUT
echo   [0]  Salir
echo.
set /p opcion="  Seleccione una opcion: "

if "%opcion%"=="1" goto INIT
if "%opcion%"=="2" goto ALL
if "%opcion%"=="3" goto FIREX
if "%opcion%"=="4" goto INVOICE
if "%opcion%"=="5" goto PLIST
if "%opcion%"=="6" goto PO
if "%opcion%"=="7" goto LINK
if "%opcion%"=="8" goto REPORT
if "%opcion%"=="9" goto OPENINPUT
if "%opcion%"=="0" goto FIN
goto MENU

:: ------------------------------------------------------------------
:INIT
cls
echo.
echo  Inicializando base de datos...
echo  (Crea las tablas 3M en PO_DataBase.accdb si no existen)
echo.
python main.py --init
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:ALL
cls
echo.
echo  Procesando todos los archivos en .\input\ ...
echo.
python main.py --all --dir .\input
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:FIREX
cls
echo.
echo  Archivos .txt disponibles en .\input\:
echo.
dir /b .\input\*.txt 2>nul || echo   (ninguno encontrado)
echo.
set /p archivo="  Nombre del archivo (Ej: firex.txt): "
if "%archivo%"=="" goto MENU
if not exist ".\input\%archivo%" (
    echo.
    echo  ERROR: No se encuentra .\input\%archivo%
    pause
    goto MENU
)
echo.
python main.py --firex ".\input\%archivo%"
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:INVOICE
cls
echo.
echo  Archivos PDF disponibles en .\input\:
echo.
dir /b .\input\*.pdf 2>nul || echo   (ninguno encontrado)
echo.
set /p archivo="  Nombre del archivo (Ej: Invoice_9437815610.pdf): "
if "%archivo%"=="" goto MENU
if not exist ".\input\%archivo%" (
    echo.
    echo  ERROR: No se encuentra .\input\%archivo%
    pause
    goto MENU
)
echo.
python main.py --invoice ".\input\%archivo%"
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:PLIST
cls
echo.
echo  Archivos PDF disponibles en .\input\:
echo.
dir /b .\input\*.pdf 2>nul || echo   (ninguno encontrado)
echo.
set /p archivo="  Nombre del archivo (Ej: Packing_List_202.pdf): "
if "%archivo%"=="" goto MENU
if not exist ".\input\%archivo%" (
    echo.
    echo  ERROR: No se encuentra .\input\%archivo%
    pause
    goto MENU
)
echo.
python main.py --plist ".\input\%archivo%"
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:PO
cls
echo.
echo  Archivos PDF disponibles en .\input\:
echo.
dir /b .\input\*.pdf 2>nul || echo   (ninguno encontrado)
echo.
set /p archivo="  Nombre del archivo (Ej: PO_204_Lilis.pdf): "
if "%archivo%"=="" goto MENU
if not exist ".\input\%archivo%" (
    echo.
    echo  ERROR: No se encuentra .\input\%archivo%
    pause
    goto MENU
)
echo.
python main.py --po ".\input\%archivo%"
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:LINK
cls
echo.
echo  Re-enlazando documentos...
echo.
python main.py --link
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:REPORT
cls
echo.
python main.py --report
echo.
pause
goto MENU

:: ------------------------------------------------------------------
:OPENINPUT
explorer "C:\EXTERIOR\3M_SYSTEM\input"
goto MENU

:: ------------------------------------------------------------------
:FIN
cls
echo.
echo  Hasta luego.
echo.
timeout /t 2 >nul
exit
